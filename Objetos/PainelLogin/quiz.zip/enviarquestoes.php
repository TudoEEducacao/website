<?php

$action=$_GET["acao"];

if($action == "cadastrarquestoes")
{
	$Enuciado=addslashes($_POST["Enuciado"]);
	
	$resposta=addslashes($_POST["resposta"]);


			$enviarquestao = new database;
			$ID = $_SESSION["IDsecao"];
			$enviarquestao = $enviarquestao->registrarQuestao($Enuciado, $resposta, $ID);
	
}

?>