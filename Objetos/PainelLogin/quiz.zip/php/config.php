<?php
class config {
    public static $server_name 	= "localhost";
    public static $username 	= "root";
    public static $password 	= "vertrigo";
    public static $db_name 		= "quiz";
    public static $port 		= "3306";

//    public static $server_name = "eua6.servidoreua6.srv.br";
//    public static $username 	= "tudoeedu";
//    public static $password 	= "aMb8KK6PpX";
//    public static $db_name 		= "tudoeedu_quiz";
//    public static $port 		= "2082";
}
?> 